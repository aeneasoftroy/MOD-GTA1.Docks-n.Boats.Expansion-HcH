# MOD-GTA1.Docks-n.Boats.Expansion-HcH
This mod adds boats and docks to 3 levels of GTA1, it's been tested on the original release and the steam release of GTA1.

This expansion mod comes in the form of a patcher, just drag the original map .CMP file to the extracted folder of the downloaded zip file and run the included patcher.bat script to add the boats and docks throughout the entire game or just per city, whatever you want!

After 22 years this game deserved some attention!

![Alt text](https://github.com/aeneasoftroy/MOD-GTA1.Docks-n.Boats.Expansion-HcH/blob/master/GTA1.Docks'n.Boats.Expansion-HcH.png)

![Alt text](https://github.com/aeneasoftroy/MOD-GTA1.Docks-n.Boats.Expansion-HcH/blob/master/2019-03-23_180725.png)

#### Enjoy,

#### Aeneas of Troy
